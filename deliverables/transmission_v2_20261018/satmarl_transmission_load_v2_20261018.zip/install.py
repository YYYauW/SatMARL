"""Verify a narrow code update; --apply backs up existing files before copying."""
from __future__ import annotations
import argparse
from datetime import datetime
import hashlib
import json
from pathlib import Path
import shutil


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--project", type=Path, required=True)
    parser.add_argument("--apply", action="store_true")
    args = parser.parse_args()
    package = Path(__file__).resolve().parent
    project = args.project.expanduser().resolve()
    if not (project/"src/sat_marl_env/env.py").is_file():
        raise RuntimeError("--project must be the existing SatMARL repository root")
    manifest = json.loads((package/"bundle_manifest.json").read_text(encoding="utf-8"))
    changes = []
    for name, record in manifest["files"].items():
        source = (package/"payload"/name).resolve()
        target = (project/name).resolve()
        if not source.is_relative_to(package/"payload") or not target.is_relative_to(project):
            raise RuntimeError("Path outside the package/project")
        if sha(source) != record["sha256"]:
            raise RuntimeError(f"Corrupt payload: {name}")
        if target.exists():
            actual = sha(target)
            if actual == record["sha256"]:
                continue
            if actual != record.get("original_sha256"):
                raise RuntimeError(f"Local changes or a different code version: {name}. No files were copied. Review this file manually.")
        changes.append((source, target, name))
    print(f"Verified {len(manifest['files'])} files; {len(changes)} updates needed.")
    if not args.apply:
        print("Dry run only. Add --apply to back up and install these verified files.")
        return
    backup = project/"backups"/("transmission_v2_"+datetime.now().strftime("%Y%m%d_%H%M%S_%f"))
    # All validation completes before the first copy. No results/weights are in the bundle.
    for source, target, name in changes:
        if target.exists():
            saved = backup/name
            saved.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(target, saved)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
    print(f"Installed. Existing files were copied to {backup}")


if __name__ == "__main__":
    main()
