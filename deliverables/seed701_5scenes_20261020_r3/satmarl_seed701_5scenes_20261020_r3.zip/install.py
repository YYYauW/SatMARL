"""Install additions, accepting only seven explicitly proved raw newline pairs."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import shutil


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def sha(path):
    return digest(path.read_bytes())


def checked_allowlist(manifest):
    required = manifest["required_existing_sha256"]
    variants = manifest.get("required_existing_sha256_variants", {})
    proof = manifest.get("required_existing_line_ending_proof", {})
    if len(variants) != 7 or set(variants) != set(proof):
        raise RuntimeError("Expected exactly seven proved newline pairs. No files copied.")
    accepted = {name: {expected} for name, expected in required.items()}
    for name, pair in variants.items():
        evidence = proof[name]
        if (name not in required or not isinstance(pair, list) or len(pair) != 2
                or len(set(pair)) != 2 or pair[0] != required[name]
                or evidence.get("original_sha256") != pair[0]
                or evidence.get("lf_sha256") != pair[1]
                or any(not isinstance(value, str) or len(value) != 64
                       or any(c not in "0123456789abcdef" for c in value) for value in pair)):
            raise RuntimeError(f"Invalid approved newline pair: {name}. No files copied.")
        accepted[name] = set(pair)
    return accepted


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project", type=Path, required=True)
    parser.add_argument("--apply", action="store_true")
    args = parser.parse_args()
    package, project = Path(__file__).resolve().parent, args.project.expanduser().resolve()
    payload = (package / "payload").resolve()
    manifest = json.loads((package / "bundle_manifest.json").read_text(encoding="utf-8"))
    accepted = checked_allowlist(manifest)
    lf_matches = []
    for name, expected in manifest["required_existing_sha256"].items():
        target = (project / name).resolve()
        if not target.is_relative_to(project) or not target.is_file():
            raise RuntimeError(f"Prerequisite missing or locally modified: {name}. No files copied.")
        raw = target.read_bytes()
        actual = digest(raw)
        if actual not in accepted[name]:
            raise RuntimeError(f"Prerequisite missing or locally modified: {name}. No files copied.")
        if name in manifest["required_existing_sha256_variants"]:
            lf = manifest["required_existing_line_ending_proof"][name]["lf_sha256"]
            if digest(raw.replace(b"\r\n", b"\n")) != lf:
                raise RuntimeError(f"Newline proof mismatch: {name}. No files copied.")
        if actual != expected:
            lf_matches.append(name)
    changes = []
    for name, record in manifest["files"].items():
        source, target = (payload / name).resolve(), (project / name).resolve()
        if not source.is_relative_to(payload) or not target.is_relative_to(project):
            raise RuntimeError("Path outside package/project. No files copied.")
        if not source.is_file() or sha(source) != record["sha256"]:
            raise RuntimeError(f"Corrupt or missing payload: {name}. No files copied.")
        if target.exists():
            if target.is_file() and sha(target) == record["sha256"]:
                continue
            raise RuntimeError(f"Different local file already exists: {name}. No files copied.")
        changes.append((source, target))
    print(f"Verified {len(manifest['files'])} payload files and {len(accepted)} prerequisites; {len(changes)} additions needed.")
    print(f"Approved LF-only prerequisite matches: {len(lf_matches)}. Original server bytes will be retained.")
    for name in lf_matches:
        print(f"  Retain LF source: {name}")
    if not args.apply:
        print("Dry run. Add --apply to install verified additions; weights, prerequisite code and results stay unchanged.")
        return
    for source, target in changes:
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
    print("Installed r3 additions. Existing code, manifests, model weights and result files were not replaced.")


if __name__ == "__main__":
    main()
