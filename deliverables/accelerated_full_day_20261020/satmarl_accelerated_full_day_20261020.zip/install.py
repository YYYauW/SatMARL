"""Install the additive accelerated evaluator without replacing serial code or data."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import shutil


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--project", type=Path, required=True)
    parser.add_argument("--apply", action="store_true")
    args = parser.parse_args()
    package, project = Path(__file__).resolve().parent, args.project.expanduser().resolve()
    manifest = json.loads((package / "bundle_manifest.json").read_text(encoding="utf-8"))
    for name, expected in manifest["required_existing_sha256"].items():
        target = (project / name).resolve()
        if not target.is_relative_to(project) or not target.is_file() or sha(target) != expected:
            raise RuntimeError(f"Prerequisite missing or locally modified: {name}. No files copied.")
    changes = []
    for name, record in manifest["files"].items():
        source, target = (package / "payload" / name).resolve(), (project / name).resolve()
        if not source.is_relative_to(package / "payload") or not target.is_relative_to(project):
            raise RuntimeError("Path outside package/project")
        if sha(source) != record["sha256"]:
            raise RuntimeError(f"Corrupt payload: {name}. No files copied.")
        if target.exists():
            if sha(target) == record["sha256"]:
                continue
            raise RuntimeError(f"Local file already exists with different contents: {name}. No files copied.")
        changes.append((source, target))
    print(f"Verified {len(manifest['files'])} files; {len(changes)} additions needed.")
    if not args.apply:
        print("Dry run. Add --apply to install verified additions; serial scripts, weights and results stay unchanged.")
        return
    for source, target in changes:
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
    print("Installed additive acceleration and controls. Existing v1 code, weights and results were not replaced.")


if __name__ == "__main__":
    main()


