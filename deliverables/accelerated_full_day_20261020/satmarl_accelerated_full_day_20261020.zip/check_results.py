"""Read-only completeness/metric checks for the agreed full-method day sweep."""
from __future__ import annotations

import argparse
import csv
import hashlib
import itertools
import json
import math
from pathlib import Path

SATELLITES = (128, 256, 512, 1024)
TASKS = tuple(range(1000, 10001, 1000))
SEEDS = (701, 702)
RATE_FIELDS = ("observation_success_rate", "observation_and_downlink_success_rate")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def read_csv(path):
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def key(row, episode=False):
    require(row["method"] == "full", "Unexpected method in results")
    result = tuple(int(row[name]) for name in ("training_seed", "satellites", "tasks"))
    return (*result, int(row["episode"])) if episode else result


def number(row, name):
    value = float(row[name])
    require(math.isfinite(value), f"Non-finite {name}")
    return value


def check_row(row):
    _, _, total, episode = key(row, episode=True)
    require(0 <= episode < 20, "Wrong episode index")
    observed = number(row, "observation_success_tasks")
    delivered = number(row, "observation_and_downlink_success_tasks")
    require(observed.is_integer() and delivered.is_integer(), "Task counts must be integers")
    require(0 <= delivered <= observed <= total, "Invalid task-success inclusion/counts")
    for name, count in zip(RATE_FIELDS, (observed, delivered)):
        require(math.isclose(number(row, name), count / total, abs_tol=1e-10, rel_tol=0),
                f"Wrong denominator or success rate: {name}")
    require(math.isclose(number(row, "simulated_seconds"), 86400, abs_tol=1e-6, rel_tol=0),
            "A simulation did not reach the 24-hour endpoint")
    require(number(row, "max_rolling_imaging_seconds") <= 1800 + 1e-6,
            "Rolling imaging constraint exceeded")


def validate(root):
    root = root.expanduser().resolve()
    progress = read_json(root / "progress.json")
    require(progress.get("status") == "complete", "Run is not complete")
    require(progress.get("completed_jobs") == progress.get("total_jobs") == 80, "Expected 80 completed jobs")
    config = read_json(root / "manifest.json")["identity"]["config"]
    require(config["methods"] == ["full"], "Expected only this method (full)")
    require(config["satellite_counts"] == list(SATELLITES), "Wrong constellation sizes")
    require(config["task_counts"] == list(TASKS), "Wrong task-count sweep")
    require(config["training_seeds"] == list(SEEDS) and config["episodes"] == 20, "Wrong model seeds or episode count")
    require(config["env"]["max_steps"] * config["env"]["step_duration_seconds"] == 86400, "Wrong horizon")
    require(config["catalog"].get("sampling_protocol") == "nested_equal_area_batches_v1", "Wrong sampling protocol")
    expected_jobs = set(itertools.product(SEEDS, SATELLITES, TASKS))
    expected_episodes = {(*job, episode) for job in expected_jobs for episode in range(20)}
    jobs, reference = {}, {}
    for seed, satellites, tasks in sorted(expected_jobs):
        path = root / "jobs" / f"full_seed{seed}_n{satellites}_m{tasks}.json"
        result = read_json(path)
        require(result.get("status") == "complete", f"Incomplete job: {path.name}")
        require(key(result["job"]) == (seed, satellites, tasks), f"Wrong job identity: {path.name}")
        rows = result["episodes"]
        require(len(rows) == 20, f"Wrong episode count: {path.name}")
        require({key(row, True) for row in rows} == {(seed, satellites, tasks, episode) for episode in range(20)},
                f"Missing/duplicated episode: {path.name}")
        for row in rows:
            check_row(row)
            reference[key(row, True)] = row
        jobs[(seed, satellites, tasks)] = {field: sum(number(row, field) for row in rows) / 20 for field in RATE_FIELDS}
    episodes = read_csv(root / "episodes.csv")
    require(len(episodes) == 1600 and {key(row, True) for row in episodes} == expected_episodes,
            "episodes.csv must contain 1600 unique expected episodes")
    for row in episodes:
        check_row(row)
        for field in RATE_FIELDS:
            require(math.isclose(number(row, field), number(reference[key(row, True)], field), abs_tol=1e-10, rel_tol=0),
                    "CSV/JSON success-rate mismatch")
    grouped = read_csv(root / "grouped.csv")
    require(len(grouped) == 80 and {key(row) for row in grouped} == expected_jobs, "Expected 80 per-model aggregates")
    for row in grouped:
        for field in RATE_FIELDS:
            require(math.isclose(number(row, field + "_mean"), jobs[key(row)][field], abs_tol=1e-10, rel_tol=0),
                    "Wrong per-model success-rate mean")
    merged = read_csv(root / "grouped_across_training_seeds.csv")
    require(len(merged) == 40, "Expected 40 merged constellation/task-count results")
    seen = set()
    for row in merged:
        satellites, tasks = int(row["satellites"]), int(row["tasks"])
        require(row["method"] == "full" and int(row["training_seed_count"]) == 2, "Wrong merged model identity/count")
        require((satellites, tasks) not in seen, "Duplicated merged result")
        seen.add((satellites, tasks))
        for field in RATE_FIELDS:
            expected = sum(jobs[(seed, satellites, tasks)][field] for seed in SEEDS) / 2
            require(math.isclose(number(row, field + "_mean"), expected, abs_tol=1e-10, rel_tol=0),
                    "Wrong merged success-rate mean")
    require(seen == set(itertools.product(SATELLITES, TASKS)), "Missing merged results")
    balance = read_json(root / "scenario_balance.json")
    require(balance["all_prefixes_balanced"] and balance["spatial_counts_identical_across_episodes"], "Spatial balance checks failed")
    require(balance["episode_count"] == len(balance["episodes"]) == 20, "Wrong balance-report scenario count")
    require({entry["episode"] for entry in balance["episodes"]} == set(range(20)), "Duplicate/missing balance scenario")
    for entry in balance["episodes"]:
        require(len(entry["scales"]) == 10 and {row["tasks"] for row in entry["scales"]} == set(TASKS), "Wrong balanced scales")
        for row in entry["scales"]:
            require(row["spatial_grid_min_count"] == row["spatial_grid_max_count"] == row["tasks"] // 1000,
                    "Nonuniform task prefix")
    assets = read_json(root / "scenario_sha256.json")
    require(len(assets) == 24, "Expected 20 catalogues and 4 orbit-cache hashes")
    for name, expected in assets.items():
        path = (root / name.replace("\\", "/")).resolve()
        require(path.is_relative_to(root), "Asset path outside the run directory")
        digest = hashlib.sha256()
        with path.open("rb") as handle:
            for block in iter(lambda: handle.read(1024 * 1024), b""):
                digest.update(block)
        require(digest.hexdigest() == expected, f"Scenario asset changed: {name}")
    return dict(completed_jobs=80, episodes=1600, merged_results=40,
                balanced_scenario_scale_checks=200, success_rates=list(RATE_FIELDS))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("run_root", type=Path)
    args = parser.parse_args()
    try:
        result = validate(args.run_root)
    except (KeyError, ValueError, OSError, TypeError) as error:
        parser.exit(1, f"NOT COMPLETE / CHECK FAILED: {error}\n")
    print("PASS: complete full-method evaluation, balanced catalogues and both success rates.")
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
