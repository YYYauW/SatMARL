"""Install a verified catalogue-only update on top of the frozen event-v3 bundle."""
from __future__ import annotations

import argparse
from datetime import datetime
import hashlib
import json
from pathlib import Path
import shutil


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--project", type=Path, required=True)
    parser.add_argument("--apply", action="store_true")
    args = parser.parse_args()
    package = Path(__file__).resolve().parent
    project = args.project.expanduser().resolve()
    manifest = json.loads((package / "bundle_manifest.json").read_text(encoding="utf-8"))
    for name, expected in manifest["required_existing_sha256"].items():
        target = (project / name).resolve()
        if not target.is_relative_to(project) or not target.is_file() or sha(target) != expected:
            raise RuntimeError(f"Event-v3 prerequisite missing or modified: {name}. No files copied.")
    changes = []
    for name, record in manifest["files"].items():
        source = (package / "payload" / name).resolve()
        target = (project / name).resolve()
        if not source.is_relative_to(package / "payload") or not target.is_relative_to(project):
            raise RuntimeError("Path outside package or project")
        if sha(source) != record["sha256"]:
            raise RuntimeError(f"Corrupt payload: {name}. No files copied.")
        if target.exists():
            previous = sha(target)
            if previous == record["sha256"]:
                continue
            if previous not in record.get("accepted_previous_sha256", []):
                raise RuntimeError(f"Local changes or a different version: {name}. No files copied. Review manually.")
        changes.append((source, target, name))
    print(f"Verified {len(manifest['files'])} files; {len(changes)} updates needed.")
    if not args.apply:
        print("Dry run. Add --apply to back up and install the verified changes.")
        return
    backup = project / "backups" / ("balanced_full_sweep_" + datetime.now().strftime("%Y%m%d_%H%M%S_%f"))
    for source, target, name in changes:
        if target.exists():
            saved = backup / name
            saved.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(target, saved)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
    print(f"Installed. Backups of replaced files: {backup}")
    print("Use configs/transmission_day_v3_full_sweep.json and a new run root.")


if __name__ == "__main__":
    main()
